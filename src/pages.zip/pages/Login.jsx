import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = ({ setRole }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userType, setUserType] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!userType) {
      alert("Please select a role before logging in!");
      return;
    }

    console.log("Login:", { email, password, userType });

    // Save role globally
    setRole(userType);

    // Redirect based on role
    if (userType === "student") navigate("/dashboard");
    else if (userType === "teacher") navigate("/teacher");
    else if (userType === "admin") navigate("/admin");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-dark-bg transition-colors duration-300">
      <div className="bg-white dark:bg-dark-card p-8 rounded-2xl shadow-neumorphic-modern dark:shadow-neumorphic-modern-dark w-full max-w-md animate-slide-up">
        <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-dark-text mb-6">
          Login to Your Account
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Select Role */}
          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Select Role
            </label>
            <select
              value={userType}
              onChange={(e) => setUserType(e.target.value)}
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
              required
            >
              <option value="">Choose your role</option>
              <option value="student">Student</option>
              <option value="teacher">Teacher</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          {/* Email */}
          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
              required
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-custom-teal to-teal-600 text-white p-3 rounded-lg hover:from-teal-500 hover:to-teal-700 transition duration-300 font-semibold shadow-glow"
          >
            Login
          </button>
        </form>

        <p className="text-center text-gray-600 dark:text-gray-400 text-sm mt-6">
          Don't have an account?{" "}
          <span
            onClick={() => navigate("/signup")}
            className="text-custom-teal hover:underline cursor-pointer"
          >
            Sign Up
          </span>
        </p>
      </div>
    </div>
  );
};

export default Login;
