import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Signup = ({ setRole }) => {
  const [formData, setFormData] = useState({
    role: "student", // default role
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    institute: "",
    enrollmentNumber: "",
    username: "",
    year: "",
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    console.log("Signup Data:", formData);

    // Save the selected role
    setRole(formData.role);

    // Redirect after signup
    navigate("/dashboard");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-dark-bg transition-colors duration-300">
      <div className="bg-white dark:bg-dark-card p-8 rounded-2xl shadow-neumorphic-modern dark:shadow-neumorphic-modern-dark w-full max-w-lg animate-slide-up">
        <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-dark-text mb-6">
          Create an Account
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Role Selection - FIRST */}
          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Select Role
            </label>
            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
            >
              <option value="student">Student</option>
              <option value="teacher">Teacher</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          {/* Extra Fields for Student Role */}
          {formData.role === "student" && (
            <>
              {/* Institute Name */}
              <div>
                <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
                  Institute Name
                </label>
                <select
                  name="institute"
                  value={formData.institute}
                  onChange={handleChange}
                  className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
                  required
                >
                  <option value="">Select Institute</option>
                  <option value="GECA">GECA</option>
                  <option value="MEM COLLEGE">MEM COLLEGE</option>
                  <option value="DEVGIRI COLLEGE">DEVGIRI COLLEGE</option>
                </select>
              </div>

              {/* Enrollment Number */}
              <div>
                <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
                  Enrollment Number
                </label>
                <input
                  type="text"
                  name="enrollmentNumber"
                  value={formData.enrollmentNumber}
                  onChange={handleChange}
                  placeholder="Enter enrollment number"
                  className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
                  required
                />
              </div>

              {/* Create Username */}
              <div>
                <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
                  Create Username
                </label>
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder="Choose a unique username"
                  className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
                  required
                />
              </div>

              {/* Year of Study */}
              <div>
                <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
                  Year of Study
                </label>
                <select
                  name="year"
                  value={formData.year}
                  onChange={handleChange}
                  className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
                  required
                >
                  <option value="">Select Year</option>
                  <option value="1st">1st Year</option>
                  <option value="2nd">2nd Year</option>
                  <option value="3rd">3rd Year</option>
                  <option value="4th">4th Year</option>
                </select>
              </div>
            </>
          )}

          {/* Common Fields for All Roles */}
          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Full Name
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="John Doe"
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
              required
            />
          </div>

          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Email Address
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Password
            </label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="••••••••"
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
              required
            />
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
              Confirm Password
            </label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="••••••••"
              className="w-full p-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:border-custom-teal focus:ring-2 focus:ring-custom-teal dark:bg-gray-800 dark:text-dark-text transition duration-200"
              required
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-custom-teal to-teal-600 text-white p-3 rounded-lg hover:from-teal-500 hover:to-teal-700 transition duration-300 font-semibold shadow-glow"
          >
            Sign Up
          </button>
        </form>

        <p className="text-center text-gray-600 dark:text-gray-400 text-sm mt-6">
          Already have an account?{" "}
          <span
            onClick={() => navigate("/login")}
            className="text-custom-teal hover:underline cursor-pointer"
          >
            Login
          </span>
        </p>
      </div>
    </div>
  );
};

export default Signup;
