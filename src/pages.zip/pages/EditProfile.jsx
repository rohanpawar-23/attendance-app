import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const EditProfile = ({ role }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [userData, setUserData] = useState({
    name: 'Rohan',
    institute: 'GECA',
    username: 'rohan123',
    branch: 'Computer Science',
    year: '2nd Year',
    enrollmentNumber: '12345678'
  });
  const [editedData, setEditedData] = useState({ ...userData });
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!role || role !== 'student') {
      navigate('/');
    }
  }, [role, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    setConfirming(true);
  };

  const handleConfirm = () => {
    if (confirming) {
      setUserData(editedData);
      navigate('/dashboard');
    }
  };

  const handleCancel = () => {
    setConfirming(false);
    setEditedData({ ...userData });
  };

  if (!role || role !== 'student') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 overflow-y-auto flex items-center justify-center">
      <div className="max-w-md mx-auto px-4 py-8">
        <section className="bg-white p-6 rounded-xl shadow-2xl">
          <h2 className="text-3xl font-semibold text-blue-700 mb-6">Edit Profile</h2>
          <div className="space-y-6">
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Name</label>
              <input
                type="text"
                name="name"
                value={editedData.name}
                onChange={handleInputChange}
                className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Institute</label>
              <input
                type="text"
                name="institute"
                value={editedData.institute}
                onChange={handleInputChange}
                className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Username</label>
              <input
                type="text"
                name="username"
                value={editedData.username}
                onChange={handleInputChange}
                className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Branch</label>
              <input
                type="text"
                name="branch"
                value={editedData.branch}
                onChange={handleInputChange}
                className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Year</label>
              <input
                type="text"
                name="year"
                value={editedData.year}
                onChange={handleInputChange}
                className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Enrollment No</label>
              <input
                type="text"
                name="enrollmentNumber"
                value={editedData.enrollmentNumber}
                onChange={handleInputChange}
                className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200"
              />
            </div>
            {!confirming ? (
              <button
                onClick={handleSave}
                className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition duration-200"
              >
                Save Changes
              </button>
            ) : (
              <div className="text-center">
                <p className="text-lg text-gray-700 mb-4">Confirm changes?</p>
                <button
                  onClick={handleConfirm}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition duration-200 mr-2"
                >
                  Yes
                </button>
                <button
                  onClick={handleCancel}
                  className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition duration-200"
                >
                  No
                </button>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default EditProfile;