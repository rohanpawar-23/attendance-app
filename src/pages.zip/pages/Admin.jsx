import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Admin = ({ role }) => {
  const navigate = useNavigate();

  useEffect(() => {
    if (!role || role !== 'admin') {
      navigate('/');
    }
  }, [role, navigate]);

  if (!role || role !== 'admin') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 overflow-y-auto">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <section className="bg-white p-6 rounded-xl shadow-2xl">
          <h2 className="text-3xl font-semibold text-blue-700 mb-6">Admin Panel</h2>
          <p className="text-lg text-gray-700">Welcome, Admin! Manage the system here.</p>
        </section>
      </div>
    </div>
  );
};

export default Admin;