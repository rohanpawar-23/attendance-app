import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const Profile = ({ role }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const userData = {
    name: 'Rohan',
    institute: 'GECA',
    username: 'rohan123',
    branch: 'Computer Science',
    year: '2nd Year',
    enrollmentNumber: '12345678'
  };

  useEffect(() => {
    if (!role || role !== 'student') {
      navigate('/');
    }
  }, [role, navigate]);

  if (!role || role !== 'student') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 overflow-y-auto flex items-center justify-center">
      <div className="max-w-md mx-auto px-4 py-8">
        <section className="bg-white p-6 rounded-xl shadow-2xl">
          <h2 className="text-3xl font-semibold text-blue-700 mb-6">My Profile</h2>
          <div className="space-y-6">
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Name</label>
              <p className="w-full p-3 border-2 border-gray-300 rounded-lg bg-gray-50">{userData.name}</p>
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Institute</label>
              <p className="w-full p-3 border-2 border-gray-300 rounded-lg bg-gray-50">{userData.institute}</p>
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Username</label>
              <p className="w-full p-3 border-2 border-gray-300 rounded-lg bg-gray-50">{userData.username}</p>
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Branch</label>
              <p className="w-full p-3 border-2 border-gray-300 rounded-lg bg-gray-50">{userData.branch}</p>
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Year</label>
              <p className="w-full p-3 border-2 border-gray-300 rounded-lg bg-gray-50">{userData.year}</p>
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">Enrollment No</label>
              <p className="w-full p-3 border-2 border-gray-300 rounded-lg bg-gray-50">{userData.enrollmentNumber}</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Profile;