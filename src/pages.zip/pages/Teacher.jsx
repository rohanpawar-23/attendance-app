import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import QRCode from 'react-qr-code';

const Teacher = ({ role }) => {
  const navigate = useNavigate();
  const [selectedOption, setSelectedOption] = useState(null);
  const [qrValue, setQrValue] = useState('');
  const [confirming, setConfirming] = useState(false);

  // Sample data for 10 students' attendance for a particular subject (e.g., Mathematics)
  const studentsAttendance = [
    { name: 'Student 1', conducted: 20, attended: 18, missed: 2, percentage: 90 },
    { name: 'Student 2', conducted: 20, attended: 17, missed: 3, percentage: 85 },
    { name: 'Student 3', conducted: 20, attended: 19, missed: 1, percentage: 95 },
    { name: 'Student 4', conducted: 20, attended: 16, missed: 4, percentage: 80 },
    { name: 'Student 5', conducted: 20, attended: 20, missed: 0, percentage: 100 },
    { name: 'Student 6', conducted: 20, attended: 15, missed: 5, percentage: 75 },
    { name: 'Student 7', conducted: 20, attended: 18, missed: 2, percentage: 90 },
    { name: 'Student 8', conducted: 20, attended: 14, missed: 6, percentage: 70 },
    { name: 'Student 9', conducted: 20, attended: 19, missed: 1, percentage: 95 },
    { name: 'Student 10', conducted: 20, attended: 17, missed: 3, percentage: 85 },
  ];

  useEffect(() => {
    if (!role || role !== 'teacher') {
      navigate('/');
    }
  }, [role, navigate]);

  if (!role || role !== 'teacher') {
    return null;
  }

  const handleClassSelection = (option) => {
    setSelectedOption(option);
  };

  const handleConfirmSelection = () => {
    if (selectedOption) {
      setConfirming(true);
    }
  };

  const handleConfirmQR = () => {
    if (confirming) {
      setQrValue(`teacher-session-${selectedOption}-${Date.now()}`);
      setConfirming(false);
    }
  };

  const handleCancel = () => {
    setSelectedOption(null);
    setConfirming(false);
    setQrValue('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 overflow-y-auto">
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        <section className="bg-white p-6 rounded-xl shadow-2xl">
          <h2 className="text-3xl font-semibold text-purple-700 mb-6">Teacher Panel</h2>
          <div className="mb-6">
            <h3 className="text-xl font-medium text-gray-700 mb-4">Taking Classes</h3>
            <div className="flex space-x-4 mb-4">
              {!selectedOption && (
                <>
                  <button
                    onClick={() => handleClassSelection('online')}
                    className="px-4 py-2 rounded-lg bg-gray-200 text-gray-700 font-semibold transition duration-200"
                  >
                    Online Class
                  </button>
                  <button
                    onClick={() => handleClassSelection('static')}
                    className="px-4 py-2 rounded-lg bg-gray-200 text-gray-700 font-semibold transition duration-200"
                  >
                    Static Class
                  </button>
                  <button
                    onClick={() => handleClassSelection('dynamic')}
                    className="px-4 py-2 rounded-lg bg-gray-200 text-gray-700 font-semibold transition duration-200"
                  >
                    Dynamic Class
                  </button>
                </>
              )}
            </div>
            {selectedOption && !confirming && (
              <div className="mt-6 text-center">
                <p className="text-lg text-gray-700 mb-4">Confirm {selectedOption} Class?</p>
                <button
                  onClick={handleConfirmSelection}
                  className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition duration-200 mr-2"
                >
                  Confirm
                </button>
                <button
                  onClick={handleCancel}
                  className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition duration-200"
                >
                  Cancel
                </button>
              </div>
            )}
            {confirming && !qrValue && (
              <div className="mt-6 text-center">
                <p className="text-lg text-gray-700 mb-4">Are you sure to generate QR for {selectedOption} Class?</p>
                <button
                  onClick={handleConfirmQR}
                  className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition duration-200 mr-2"
                >
                  Yes
                </button>
                <button
                  onClick={handleCancel}
                  className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition duration-200"
                >
                  No
                </button>
              </div>
            )}
            {qrValue && (
              <div className="mt-6 text-center">
                <h3 className="text-xl font-medium text-gray-700 mb-4">QR Code for {selectedOption} Class</h3>
                <QRCode value={qrValue} size={250} className="mx-auto mb-4" />
                <p className="mt-2 text-gray-600">Session ID: {qrValue}</p>
              </div>
            )}
          </div>
          <p className="text-lg text-gray-700 mt-6">Manage your classes and attendance here.</p>
        </section>

        <section className="bg-white p-6 rounded-xl shadow-2xl">
          <h3 className="text-2xl font-medium text-gray-700 mb-4">Student Attendance for Mathematics</h3>
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-200">
                <th className="p-3 border text-left">Student Name</th>
                <th className="p-3 border text-left">Conducted</th>
                <th className="p-3 border text-left">Attended</th>
                <th className="p-3 border text-left">Missed</th>
                <th className="p-3 border text-left">Percentage</th>
              </tr>
            </thead>
            <tbody>
              {studentsAttendance.map((student, index) => (
                <tr key={index} className="hover:bg-gray-50 transition duration-200">
                  <td className="p-3 border">{student.name}</td>
                  <td className="p-3 border">{student.conducted}</td>
                  <td className="p-3 border">{student.attended}</td>
                  <td className="p-3 border">{student.missed}</td>
                  <td className="p-3 border">{student.percentage}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
};

export default Teacher;